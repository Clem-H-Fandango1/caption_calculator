# Changelog

## v1.4
- Simplified instructions
- Clean BOL-specific wording
- Stable marker export
- Clean CSV export

## v1.3
- Validation improvements

## v1.2
- UI tidy pass

## v1.1
- Marker export added

## v1.0
- Initial working caption extraction
